#pragma once
#include "Object.h"

class Gift :
    public Object
{
public:
    Gift(int x, int y);
    void paint();


};

