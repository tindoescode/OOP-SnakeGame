#include "X2Point.h"
#include "Snake.h"

void X2Point::operate(std::shared_ptr<Snake> snake)
{
	snake->setX2Point(30);
}
