19CLC6
+) Detail of students (mssv name email)
19127478 Bùi Huỳnh Trung Nam 19127478@student.hcmus.edu.vn
19127582 Nguyễn Trung Tín 19127582@student.hcmus.edu.vn
19127622 Ngô Trường Tuyển 19127622@student.hcmus.edu.vn

+) Details of Project:
Name: Snake Game
Description: We create fundamental contents of this game by ourself without refering so much in other sources code.
After that, we add new function and try to make this game is more interesting by pass round, random item shop,...

+) New functions:
1/player
2/2 players
3/new maps
4/Level(pass round)
5/Dynamic menu
6/save game
7/load game
8/pause -continue
9/top player score
10/background music

we do all function that we send in moodle before. 

we want finit-state machine is higher score than other parts because it take us more time to do. Beside it, radom items and 2 player are interting to play than orther part.

+) Link Demo:
+) We allow to share this sources code and clip demo of this project
